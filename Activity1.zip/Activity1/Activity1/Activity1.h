#ifndef ACTIVITY1_H_INCLUDED
#define ACTIVITY1_H_INCLUDED
#define Set_Led DDRB|=(1<<PB0)
#define Set_Button DDRD&=~(1<<PD1)
#define Pullup_Button PORTD|=(1<<PD1)
#define Set_Heater DDRD&=~(1<<PD2)
#define Pullup_Heater PORTD|=(1<<PD2)
void Activity1();
#endif // ACTIVITY1_H_INCLUDED
