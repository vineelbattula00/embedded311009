#include <avr/io.h>
#include <util/delay.h>
#include "Activity1.h"
void Activity1(){
    Set_Led;
    Set_Button;
    Pullup_Button;
    Set_Heater;
    Pullup_Heater;
}


