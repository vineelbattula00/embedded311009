#ifndef ACTIVITY4_H_INCLUDED
#define ACTIVITY4_H_INCLUDED
#include <avr/io.h>
#include <util/delay.h>
#define UART_DATA_NOT_RECEIVED !(UCSR0A & (1<<RXC0))
#define UART_DATA_NOT_WRITTEN !(UCSR0A & (1<<UDRE0))
void UARTinit(uint16_t ubrr_value);
char UARTreadchar();
void UARTwritecharacter(char data);
#endif
