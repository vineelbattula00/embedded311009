#ifndef ACTIVITY3_H_INCLUDED
#define ACTIVITY3_H_INCLUDED
PWM_pins();
PWM_output(uint16_t);
#endif // ACTIVITY3_H_INCLUDED
