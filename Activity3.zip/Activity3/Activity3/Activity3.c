#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#define PWM (PORTB1)
void PWM_pins()
{
    TCCR1A|=(1<<COM1A1)|(3<<WGM10);
    TCCR1B|=(5<<CS10)|(1<<WGM12);
    DDRB|=(1<<PWM);
}
void PWM_output(uint16_t adc)
{
    OCR1A=adc;
    _delay_ms(200);
}
